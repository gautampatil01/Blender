Windows Generator 3
====================

Blender add-on for creating windows.

This add-on is based on the popular SayProduction windows generator add-on 2

This upgrade add the following new features:

- Now you can change the parameters of the windows after unselect.
- Materials are created for Cycles


** This script is deprecated now. The new versions will be integrated in Archimesh.