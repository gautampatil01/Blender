IsKeyFree
=================

Blender addon for verifying if one shortcut is free.

You can use it to find where a shortcut is used to for learning purposes.

Changes in version 1.0.1
===========================
- Changed add-on name to make easier find it in user preferences screen.