Display material relationship
==============================

Blender addon for display the objects using the selected material.

The info panel appears in the properties panel, under material tab.

To install, just copy the file to addon folder and enable it.
