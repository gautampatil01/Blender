Turnaround camera
=================

Blender addon for adding camera rotation around an object.

You can create rotation around any axis combination and back and forward actions.

Changes in version 0.2
=============================
- Added Dolly zoom effect


Changes in version 0.2.4
=============================
- Fixed error when no scene camera is defined