Doc_scenes
=======

This addon create documentation of blend files in HTML format including renders, linked files, storyboards and images used.

Changes in version 0.3
=============================
- Added a new panel to create Storyboards base on grease pencil marks.
- Added author in header information.
- Added option to remove header information.
- Bug fixing.

Changes in version 1.0
=============================
- Fixed for new Blender versions.


Changes in version 1.1
=============================
- Fixed error for slot empty.