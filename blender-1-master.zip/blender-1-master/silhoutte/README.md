Display silhoutte
=================

Blender addon to display silhoutte

More information in: http://community.cgcookie.com/t/tip-add-on-for-animator-to-display-silhouettes/398

Changes in version 1.1
=============================
- New button to create a backup in the same folder with the date and time appended at the end to the file name.

Changes in version 1.2
=============================
- Now it's possible to enter python formulas in stamp notes for adding dynamic information in renders.
